<?php include("header.php")?>
 <style>




</style>
<div class="container-fluid" style="background-color: transparent;">
  <div class="row">
	  <br>
    <h1 class="text-center text-primary">Director's Profile</h1>
    <br>
</div>
<div class="row">
    <div class="col-md-4">
      <div class="">
       <img class="center-block img-responsive img-rounded" src="images/dir.jpg">
		  <section  style="text-align: center; padding:inherit;">
		  	<h3><strong>Prof. V. K. Dwivedi</strong></h3>
			  <p style="font-family: 'Chewy', cursive; font-size:18px">Education Detail </p>
		  </section>
		  
   
      </div>
  </div>
      <div class="col-md-7">
      <div class="">
        <h3><strong>Prof. V. K. Dwivedi</strong></h3>
		  <br>
  <p>"BCE provides the students with a holistic experience for life and equip them with a congenial atmosphere to create </p> <p>intellectual technologists and entrepreneurs. Value education and Professional ethics are an integral part of our curriculum.</p>  <p>Our Training and Placement cell plays a key role in improving the quality of placements in terms of job "</p>          

        </div>
  </div>
  </div>
  </div>
  
  
<?php include("footer.php")?>
