
<!-- header -->

<?php include("header.php")?>

	

<!--SlideBox-->
	
	
	<!-- /.modal -->
	
<div class="modal fade" id="overlay">
  <div class="modal-dialog">
    <div class="modal-content bg-transparent">
      <div class="modal-header bg-transparent">
       
      
notifictionon

      </div>
    </div>
  </div>
</div>
<!-- /.modal end -->
	
	
	
<!---->


	<br>
	<!--Bootstrap Responsive Full-Width Slider-->

	<?php include("pages/banner.php")?>


	
<!-- about -->
<div class="about-top" id="about">
  <div class="container">
    <!--<h3 class="deva-title">About Us</h3>
    <div class="bce_header">
      <p><i class="fa fa-graduation-cap" aria-hidden="true"></i></p>
    </div>-->
    <div class="col-md-7 pkmkb-services-bottom-grids">
      <div class="pkmkb-services-left"> <img src="images/g11.jpg" alt=""> </div>
     
      <div class="clearfix"> </div>
    </div>
    <div class="col-md-5 pkmkb-about-grids">
      <p>Bansal College of Engineering, Mandideep, was established in 2002 by Shriniwas Education Society with a mission to provide the society with qualified technocrats. It is the second in the chain of educational institutes established by the society, which has completed 15 years ...</p><br>
      <a href="#" class="trend-deva" data-toggle="modal" data-target="#myModal"><span>Read More</span></a> </div>
    <div class="clearfix"> </div>
  </div>
</div>
	<div id="mybutton">
<button data-toggle="modal" data-target="#myModal4" class="feedback">Admission Enquiry</button>
</div>
<!-- modal -->
<div class="modal about-modal bansal-agileits fade" id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body"> <img src="images/banner2.jpg" alt="">
        <p>Bansal College of Engineering, Mandideep, was established in 2002 by Shriniwas Education Society with a mission to provide the society with qualified technocrats. It is the second in the chain of educational institutes established by the society, which has completed 15 years. It has been trying to achieve its goal, thus, trying to turn dream into reality. It began its journey with just two hundred and forty students, but now it has thousands of members.Bansal College Of Engineering, Mandideep has established itself as one of the premier institutes of India.BCE provides the students with a holistic experience for life and equip them with a congenial atmosphere to create intellectual technologists and entrepreneurs. Value education and Professional ethics are an integral part of our curriculum. Our Training and Placement cell plays a key role in improving the quality of placements in terms of job opportunities by enhancing industry-academia association through frequent visits, interaction with the top officials and facilitation of faculty development programmes.The college has been developed with an outlook of creating the engineers, who should be employable by virtue of their exposure to the active physical participation in the subjects being theoretically studied. This is the out come of the multiple industrial visits, guest lectures from prominent personalities of different industries, which allows the students to understand the industrial requirements. This in turn is certainly helping the excellent growth in the employment for students of BCE, many of them are making BCE proud by their contributions in MNCs, and even by their overseas assignments. </p>
      </div>
    </div>
  </div>
</div>
<!-- //modal --> 
	
	
	
	
<!-- //about --> 
<!--stats
<div class="stats" id="stats">
  <div class="container">
    <div class="stats-info">
      <div class="col-md-3 col-xs-3 stats-grid slideanim"> <i class="fa fa-users" aria-hidden="true"></i>
        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='499' data-delay='.5' data-increment="1">499</div>
        <h4 class="stats-info">PLACEMENT &nbsp; JOB</h4>
      </div>
      <div class="col-md-3 col-xs-3 stats-grid slideanim"> <i class="fa fa-book" aria-hidden="true"></i>
        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='10' data-delay='.5' data-increment="1">10</div>
        <h4 class="stats-info">COURSES ACTIVE</h4>
      </div>
      <div class="col-md-3 col-xs-3 stats-grid slideanim"> <i class="fa fa-trophy" aria-hidden="true"></i>
        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='11000' data-delay='.5' data-increment="10">11000</div>
        <h4 class="stats-info">STUDENTS ENROLLED</h4>
      </div>
      <div class="col-md-3 col-xs-3 stats-grid slideanim"> <i class="fa fa-user" aria-hidden="true"></i>
        <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='40' data-delay='.5' data-increment="1">40</div>
        <h4 class="stats-info">CERTIFIED TEACHERS</h4>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</div>-->

<div class="stats" id="stats">
  <div class="container">
		
  </div>
</div>


<div class="team-deva" id="team">
  <div class="fluid-container">
    <h3 class="deva-title">Awesome Teachers</h3>
	  <p style="text-align: center; font-family: 'Chewy', cursive; font-size:18px ">MEET OUR PROFESSORS </p>
   
  
  <div class="brands">
    <div class="brands__preWrapper">
      <div class="brands__wrapper">
        <a href="#"><img src="images/teachers/1.jpg" height="160" width="80"></a>
        <a href="#"><img src="images/dir.jpg"></a>
        <a href="#"><img src="images/teachers/anirudh.jpg"></a>
        <a href="#"><img src="images/download.jpg"></a>
        <a href="#"><img src="images/teachers/mamta.jpg"></a>
        <a href="#"><img src="images/RGPV-01.jpg"></a>
        <a href="#"><img src="http://placehold.it/300x150"></a>
       
       
      </div>
    </div>
  

 
</div>
    
  </div>
</div>


<!--//stats-->
	<br>
	<br>
	
	<?php include("pages/news.php")?>
      
	
	
	
<!-- services -->
<div class="services" id="services"  style="background:#740001;" >
<div class="container"  >
  
  
  <div class="team-deva-grid">
    <div class="col-md-4 col-xs-4 about-poleft t1">
      <div class="about_img"><img src="images/Sunilbansal.jpg" height="200px" alt="">
        <h5>Er. Sunil Bansal <br>(Secretary)</h5>
        <div class="about_opa">
          
          <ul class="fb_icons2 text-center">

          <li> "We at BANSAL Group, are committed to employability of our students by enhancing their theoretical knowledge coupled by practical skills, resulting into high level of placements of the Group Students."</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-xs-4 about-poleft t2">
      <div class="about_img"><img src="images/jainsir.jpg" height="200px" alt="">
        <h5>Dr. Sanjay Jain <br> (Jt. Secratary, BGI)</h5>
        <div class="about_opa">

          <ul class="fb_icons2 text-center">
            <li> "Amalgamation of students's skills with the needs of the society, Corporate world, culture, ever growing technology and the students CONFIDENCE to prove his presence at GLOBAL PERSPECTIVE, is what we are concerned the most"</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-xs-4 about-poleft t1">
      <div class="about_img"><img src="images/dir.jpg" height="200px" alt="">
        <h5>Prof. V. K. Dwivedi<br>(Director)</h5>
        <div class="about_opa">
         
          <ul class="fb_icons2 text-center">
            <li> "BCE provides the students with a holistic experience for life and equip them with a congenial atmosphere to create intellectual technologists and entrepreneurs. Value education and Professional ethics are an integral part of our curriculum. Our Training and Placement cell plays a key role in improving the quality of placements in terms of job "</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
</div>
<!-- //services --> 

<!-- team -->
<div class="team-deva" id="team">
  <div class="container">
    <h3 class="deva-title">Departments</h3>
   <br>
   <br>
    <div class="team-deva-grid">
      <div class="col-md-4 col-xs-4 about-poleft t1">
        <div class="about_img">
			<a href="cs_detail.php"><img src="images/g11.jpg" alt=""></a>
          <h5>COMPUTER SCIENCE</h5>
        </div>
      </div>
      <div class="col-md-4 col-xs-4 about-poleft t2">
        <div class="about_img">
			<a href="me_detail.php"><img src="images/g11.jpg" alt=""></a>
          <h5>MECHANICAL ENG.</h5>
        </div>
      </div>
      <div class="col-md-4 col-xs-4 about-poleft t3">
        <div class="about_img">
			<a href="el_detail.php">
				<img src="images/g11.jpg" alt=""></a>
          <h5>ELECTRICAL ENG.</h5>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
    <div class="team-deva-grid grid-2-team">
      <div class="col-md-4 col-xs-4 about-poleft t1">
        <div class="about_img">
			<a href="civil_detail.php">
				<img src="images/g11.jpg" alt=""></a>
          <h5>CIVIL ENGINEERING</h5>
        </div>
      </div>
      <div class="col-md-4 col-xs-4 about-poleft t2">
        <div class="about_img">
			<a href="cs_detail.php">
				<img src="ec_detail.php" alt=""></a>
          <h5>ELECTRONIC ENG.</h5>
        </div>
      </div>
      <div class="col-md-4 col-xs-4 about-poleft t3">
        <div class="about_img">
			<a href="1styear.php">
				<img src="images/g11.jpg" alt=""></a>
          <h5>FIRST YEAR</h5>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</div>
	
	


<div class="fluid-container">
  <div class="brands">
    <div class="brands__preWrapper">
      <div class="brands__wrapper">
        <a href="#"><img src="images/logo slider/accent.png"></a>
        <a href="#"><img src="images/logo slider/adani-02.jpg"></a>
        <a href="#"><img src="images/logo slider/advantmed-01.jpg"></a>
        <a href="#"><img src="images/logo slider/axis-bank-01.jpg"></a>
        <a href="#"><img src="images/logo slider/bestpeers-02.jpg"></a>
        <a href="#"><img src="images/logo slider/bhilwara-01.jpg"></a>
        <a href="#"><img src="images/logo slider/byjus-01.jpg"></a>
        <a href="#"><img src="images/logo slider/capgemini-01.jpg"></a>
        <a href="#"><img src="images/logo slider/cognizant-01.jpg"></a>
        <a href="#"><img src="images/logo slider/cp11.png"></a>
        <a href="#"><img src="images/logo slider/cp36.png"></a>
        <a href="#"><img src="images/logo slider/diffusion-01.jpg"></a>
        <a href="#"><img src="images/logo slider/epic-02.jpg"></a>
        <a href="#"><img src="images/logo slider/HCL-logo-01.jpg"></a>
        <a href="#"><img src="images/logo slider/infosys-01.jpg"></a>
        <a href="#"><img src="images/logo slider/jaro-education-01.jpg"></a>
        <a href="#"><img src="images/logo slider/lt-infotech-01.jpg"></a>
        <a href="#"><img src="images/logo slider/mindtree-01.jpg"></a>
        <a href="#"><img src="images/logo slider/mphasis-01.jpg"></a>
        <a href="#"><img src="images/logo slider/nucleus-01.jpg"></a>
        <a href="#"><img src="images/logo slider/peol-01.jpg"></a>
        <a href="#"><img src="images/logo slider/sg2.png"></a>
        <a href="#"><img src="images/logo slider/tcs-01.jpg"></a>
        <a href="#"><img src="images/logo slider/tech-mahindra-01.jpg"></a>
        <a href="#"><img src="images/logo slider/torry-harris-01.jpg"></a>
        <a href="#"><img src="images/logo slider/wipro-01.jpg"></a>
        <a href="#"><img src="images/logo slider/xoriant-01.jpg"></a>
      </div>
    </div>
  </div>

 
</div>
	
	<!-- Gallery -->
<?php include("pages/gellary.php")?>
<!-- //gallery --> 
	

<!--map-->
	<hr/>
	<div class=container-fluid>
	<div class="google-map">
	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14686.563395674879!2d77.5578222!3d23.0369556!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x904de6b62042ca1!2sBansal+College+Of+Engineering!5e0!3m2!1sen!2sin!4v1534149070722" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>	
	</div>	
<!--//map-->
<!-- footer -->
<?php include("footer.php")?>

<!-- //footer --> 

	
