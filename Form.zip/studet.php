<?php include("header.php")?>
 <style>
.row{
  margin-top: 40px;
}


.list-group {
    list-style: disc inside;

}

.list-group-item {
    display: list-item;
}

 .find-more{
   text-align: right;
 }


.label-theme{
  background: #3AAA64;
  font-size: 14px;
  padding: .3em .7em .3em;
  color: #fff;
  border-radius: .25em;
}

.label a{
  color: inherit;
}

   position: relative;
  }
  ul.nav-pills {
    top: 20px;
    position: fixed;
  }
  div.col-sm-9 div {
    height: 250px;
    font-size: 28px;
  }
  #section1 {color: #fff; background-color: #1E88E5;}
  #section2 {color: #fff; background-color: #673ab7;}
  #section3 {color: #fff; background-color: #ff9800;}
  #section41 {color: #fff; background-color: #00bcd4;}
  #section42 {color: #fff; background-color: #009688;}
  
  @media screen and (max-width: 810px) {
    #section1, #section2, #section3, #section41, #section42  {
      margin-left: 150px;
    }
  }
</style>
 
    <div class="container ">
      <div class="teacher-name" style="padding-top:20px;">

        <div class="row" style="margin-top:0px;">
        <div class="col-md-9">
          <h2 style="font-size:38px; text-align: center;"><strong>Devendra Kumar</strong></h2>
        </div>
        <div class="col-md-3">
          <div class="button" style="float:right;">
            <!--<a href="#" class="btn btn-outline-success btn-sm"><strong style="color: white;" >Edit Profile</strong></a>-->
          </div>
        </div>
        </div>
      </div>

      <div class="row" style="margin-top:20px; ">
        <div class="col-md-3"> <!-- Image -->
          <a href="#"> <img class="rounded-circle" src="images/1456160.png" alt="teacher" style="width:200px;height:200px"></a>
        </div>

        <div class="col-md-6"> <!-- Rank & Qualifications -->
          <h5 style="font-size: 18px;"> <p style="color:black;  font-size: 18px;"><strong>Bansal college of engineering, Mandideep</strong></p>
			<strong  style=" font-size: 18px;"> Department:</strong> Computer Science</h5>
    
          <p style="color:black; font-size: 18px;"><strong>Year of Admission:</strong> 2017-2021</p>
          <p style="color:black; font-size: 18px;"><strong>Address:</strong> Bhopal</p>
          <p style="color:black; font-size: 18px;"><strong>Email:</strong> xxx@gmail.com</p>
			<span class="number" style="font-size:18px"><strong>Phone:</strong>+9192045xxx55</span>
        </div>

        <div class="col-md-3 text-center"> <!-- Phone & Social -->
          
          <!--<div class="button" style="padding-top:18px">
            <a href="mailto:xxx@gmail.com.com" class="btn btn-outline-success btn-block"><strong style="color: white;">Send Email</strong></a>
          </div>-->
          <!--<div class="social-icons" style="padding-top:18px">
            <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x" style="color:#3AAA64"></i>
              <i class="fa fa-linkedin fa-stack-1x fa-inverse"></i>
            </span></a>
            <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x" style="color:#3AAA64"></i>
              <i class="fa fa-google-plus fa-stack-1x fa-inverse"></i>
            </span></a>
            <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x" style="color:#3AAA64"></i>
              <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
            </span></a>
            <a href="#">
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x" style="color:#3AAA64"></i>
              <i class="fa fa-slideshare fa-stack-1x fa-inverse"></i>
            </span></a>

          </div>-->
        </div>
      </div>
    </div>
  
    <!--End of Header-->

<!-- Main container -->
  <div class="container">

<!-- Section:detail -->
  <div class="row">
        <div class="col-md-3" style="background:">
         

        </div>
      </div>
<!-- End:detail -->
<div class="container">
  

  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Notice</a></li>
    
    <li><a data-toggle="tab" href="#menu1">Download</a></li>
    <li><a data-toggle="tab" href="#menu2">Result</a></li>
    <li><a data-toggle="tab" href="#menu3">Resources</a></li>
	  <li><a data-toggle="tab" href="#menu4">Forms</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <div class="row">
      <div class="col-md-12">
          <div class="card card-block text-xs-left" style="margin-bottom:15px;">
            
            <div style="height: 15px"></div>
            <ul class="list-group">
              <li class="list-group-item"><a href="33">A H M Kamal,"Inserting Item to a Sorted List",USTC Teachers Annual (USTA - 2002),8(1),2002</a> <strong style="color: red">19 april</strong></li>
             
            </ul>
          </div>
      </div>
  </div>
    </div>
    <div id="menu1" class="tab-pane fade">
      <div class="row">
    <div class="col-md-12">
        <div class="card card-block">
         
          <div style="height: 15px"></div>
          <table class="table table-bordered">
            <thead class="thead-default">
              <tr>
                <th>File</th>
                <th>Downloads</th>
              </tr>
            </thead>
            <tbody>
              <tr>
				   <td style="border-left: 3px solid #009688;">Bubble sort. Bubble sort, sometimes referred to as sinking sort, is a simple sorting algorithm that repeatedly steps through the list to be sorted, compares each pair.
                  
                </td>
                <td> <span class="label label-theme"><i class="fa fa-download-o"><a href="#"> download</a> </i></span></td>
               
              </tr>
				
				 <tr>
				   <td style="border-left: 3px solid #009688;">Bubble sort. Bubble sort, sometimes referred to as sinking sort, is a simple sorting algorithm that repeatedly steps through the list to be sorted, compares each pair.
                  
                </td>
                <td> <span class="label label-theme"><i class="fa fa-download-o"><a href="#"> download</a> </i></span></td>
               
              </tr>
				
				 <tr>
				   <td style="border-left: 3px solid #009688;">Bubble sort. Bubble sort, sometimes referred to as sinking sort, is a simple sorting algorithm that repeatedly steps through the list to be sorted, compares each pair.
                  
                </td>
                <td> <span class="label label-theme"><i class="fa fa-download-o"><a href="#"> download</a> </i></span></td>
               
              </tr>
            
            </tbody>
          </table>
        </div>
    </div>
  </div>
    </div>
    <div id="menu2" class="tab-pane fade">
     <div class="row">
      <div class="col-md-12">
          <div class="card card-block text-xs-left" style="margin-bottom:15px;">
            
            <div style="height: 15px"></div>
            <ul class="list-group">
              <li class="list-group-item"><a href="33">A H M Kamal,"Inserting Item to a Sorted List",USTC Teachers Annual (USTA - 2002),8(1),2002</a> <strong style="color: red">19 april</strong></li>
             
            </ul>
          </div>
      </div>
  </div>
    </div>
    <div id="menu3" class="tab-pane fade">
     <div class="row">
    <div class="col-md-12">
        <div class="card card-block">
         
          <div style="height: 15px"></div>
          <table class="table table-bordered">
            <thead class="thead-default">
              <tr>
                <th>Date</th>
                <th>Info</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>19 june</td>
                <td style="border-left: 3px solid #009688;">Bubble sort. Bubble sort, sometimes referred to as sinking sort, is a simple sorting algorithm that repeatedly steps through the list to be sorted, compares each pair.
                  <div class="find-more">
                    Find out more on:
                    <span class="label label-theme"><i class="fa fa-file-pdf-o"><a href="#"> PDF</a></i></span>
                    <span class="label label-theme"><i class="fa fa-youtube-square"><a href="#"> YouTube</a></i></span>
                    <span class="label label-theme"><i class="fa fa-slideshare"><a href="#"> SlideShare</a></i></span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>20 june</td>
                <td style="border-left: 3px solid #009688;">A greedy algorithm is an algorithmic paradigm that follows the problem solving heuristic of making the locally optimal choice at each stage with the hope of finding a global optimum.
                  <div class="find-more">
                    Find out more on:
                    <span class="label label-theme"><i class="fa fa-file-pdf-o"><a href="#"> PDF</a></i></span>
                    <span class="label label-theme"><i class="fa fa-youtube-square"><a href="#"> YouTube</a></i></span>
                    <span class="label label-theme"><i class="fa fa-slideshare"><a href="#"> SlideShare</a></i></span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>21 june</td>
                <td style="border-left: 3px solid #009688;">Electronic data interchange (EDI) is a major innovation in the practical use of computing. It is already being used extensively in some segments of the retailing
                  <div class="find-more">
                    Find out more on:
                    <span class="label label-theme"><i class="fa fa-file-pdf-o"><a href="#"> PDF</a></i></span>
                    <span class="label label-theme"><i class="fa fa-youtube-square"><a href="#"> YouTube</a></i></span>
                    <span class="label label-theme"><i class="fa fa-slideshare"><a href="#"> SlideShare</a></i></span>
                  </div>
                </td>

              </tr>
            </tbody>
          </table>
        </div>
    </div>
  </div>
    </div>
	  
	  <div id="menu4" class="tab-pane fade">
      <!-- Section:Publications -->
  <div class="row">
      <div class="col-md-12">
          <div class="card card-block text-xs-left" style="margin-bottom:15px;">
          
            <div style="height: 15px"></div>
            <ul class="list-group">
              <li class="list-group-item"><a href="33">A H M Kamal,"Inserting Item to a Sorted List",USTC Teachers Annual (USTA - 2002),8(1),2002</a> <strong style="color: red">19 april</strong></li>
             
            </ul>
          </div>
      </div>
  </div>
<!-- End:Publications -->

    </div> 
	  
  </div>
</div>
	  
	  
	  


  



</div> <!--End of Container-->
  
<?php include("footer.php")?>
