-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2020 at 02:54 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bce`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `recipt_num` int(255) UNSIGNED NOT NULL,
  `full name` text NOT NULL,
  `email` text NOT NULL,
  `department` text NOT NULL,
  `enrollment_num` text NOT NULL,
  `year` int(255) NOT NULL,
  `course` text NOT NULL,
  `fee` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`recipt_num`, `full name`, `email`, `department`, `enrollment_num`, `year`, `course`, `fee`) VALUES
(208147, 'prabhu', 'devendravishwakarmaa@gmail.com', 'CSE', '0127ec17155', 3, 'machine learning', 300),
(212239, 'devendra vishwakarma', 'devendravishwakarmaa@gmail.com', 'CSE', '0127ec171019', 2, 'python', 100),
(363960, 'devendra vishwakarma', 'devendravishwakarmaa@gmail.com', 'ME', '0127ec171019', 1, 'c/c++', 200),
(464347, 'devendra vishwakarma', 'dev2311999@gmail.com', 'CSE', '0127cs171018', 3, 'machine learning', 300),
(467453, 'devendra vishwakarma', 'devendravishwakarmaa@gmail.com', 'EC', '0127ec171018', 1, 'c/c++', 200),
(773219, 'prabhu', 'devendravishwakarmaa@gmail.com', 'CSE', '0127ec17155', 3, 'machine learning', 300);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`recipt_num`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
