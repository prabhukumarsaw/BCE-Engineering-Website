<?php
session_start();
if (isset($_POST['check_mark'])) {

    $r_num=rand(100000,999999);

    $_SESSION['r_num']=$r_num;

    $name=$_POST['full_name'];

    $email=$_POST['email'];

    $phone=$_POST['phone'];

    $department=$_POST['department'];

    $enroll_num=$_POST['enroll_num'];

    $year=$_POST['year'];

    $course=$_POST['course'];

    $fee=0;

    if ($course=='python') {
      $fee=100;
    }
    elseif ($course=='c/c++') {
    
    $fee=200;
    }

    else
    {
      $fee=300;
    }




    $sql="INSERT INTO `event`(`recipt_num`, `full name`, `email`, `department`, `enrollment_num`, `year`, `course`, `fee`) VALUES (
    $r_num,'$name','$email','$department','$enroll_num',$year,'$course','$fee')";


    $con = mysqli_connect("localhost","root");

    mysqli_select_db($con,"bce");

    if ($year==1 && $course=="c/c++"){

      mysqli_query($con,$sql);

      header("location:recipt.php");

mysqli_query($con,$sql);

      header("location:recipt.php");

    }
    elseif ($year==2 && ($course=="python" || $course=="c/c++") && ($department != "CE" && $department != "ME" )) {
  
 mysqli_query($con,$sql);

      header("location:recipt.php");

      }
     
     elseif ($course!="c/c++" && $year==3 && $department != "CE" && $department != "ME" ) {

  mysqli_query($con,$sql);

      header("location:recipt.php");
      
     }

     elseif ($year==4 && $course=='python') {

     mysqli_query($con,$sql);

      header("location:recipt.php");

       
     }

     echo "<script> alert('pls  fill correct information') </script>";




}
?>

<!DOCTYPE html>
<html>
<head>
<title>Training form</title>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel="stylesheet" href="style.css">
	
</head>
<body>
<div class="container">
	<h1 class="text-center">Traning Form 2020</h1><br>
<form   method="post" class="form-horizontal">
  <div class="form-group">
    <label  class="col-md-4 control-label" for="full_name">Full Name:</label>
    <div class="col-md-6">
      <input id="first_name" name="full_name" type="text" class="form-control input-md">
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="email">Email address:</label>
    <div class="col-md-6">
      <input id="email" name="email" type="email" class="form-control">
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="phone">Mobile:</label>
    <div class="col-md-6">
      <input id="phone" name="phone" type="phone" class="form-control">
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="last_name">Department:</label>
    <div class="col-md-6">
      <select name="department" class="form-control" id="sel1">
        <option value="CSE" >CSE</option>
        <option value="EC">EC</option>
        <option value="EX">EX</option>
        <option value="CE">CE</option>
        <option value="ME" >ME</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="full_name">Enrollment No:</label>
    <div class="col-md-6">
      <input id="first_name" name="enroll_num" type="text" class="form-control input-md">
    </div>
  </div>
 
  <div class="form-group">
    <label class="col-md-4 control-label" for="last_name">Year:</label>
    <div class="col-md-6">
      <select  name="year" class="form-control" id="sel1">
        <option value=1 >1</option>
        <option value=2 >2</option>
        <option value=3 >3</option>
        <option  value=4 >4</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="last_name">Choose Course:</label>
    <div class="col-md-6">
      <select  name="course" class="form-control" id="sel1">
        <option value="python">Python</option>
        <option value="machine learning">Machine Learning</option>
        <option value="c/c++">C/C++</option>
        
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-md-4 control-label underline"> <strong>Note:</strong> </div>
    <div class="col-md-6 text-center">
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              
              <th>S.No</th>
              <th>Course Name</th>
              <th>Fee</th>
              <th>Department</th>
              <th>Year</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Python</td>
              <td>100</td>
              <td>CSE,EC,EX</td>
              <td>2nd & 3rd </td>
				
            </tr>
			  
			   <tr>
              <td>2</td>
              <td>C/C++</td>
              <td>200</td>
              <td>CSE,EC,EX,CE,ME</td>
              <td>1st & 2nd </td>
				
            </tr>
			  
			   <tr>
              <td>3</td>
              <td>Machine Learning</td>
              <td>300</td>
              <td>CSE,EC,EX</td>
              <td>3rd & 4th </td>
				
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="advanced"></label>
    <div class="col-md-6">
      <div class="checkbox">
  <label><input type="checkbox" name="check_mark" value="check"><b>I agree to the filled form.</b></label>
</div>
     
    </div>
  </div>
  <button type="submit" class="btn btn-success  col-md-offset-4">Submit</button>
	 
    
 
</form>
	<br>
	<br>
</div>
<!-- partial -->
<script>
function myFunction() {
  window.print();
}
</script>
</body>
</html>
