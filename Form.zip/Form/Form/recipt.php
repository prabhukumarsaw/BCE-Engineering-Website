<?php
session_start();

$r_num=$_SESSION['r_num'];

$con = mysqli_connect("localhost","root");

    mysqli_select_db($con,"bce");

    $sql="SELECT * FROM `event` WHERE 
recipt_num=$r_num";
 
  $result= mysqli_query($con,$sql);

  $num=mysqli_num_rows($result);

  $data=mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>recipt</title>
</head>
<body>

	<h2>BANSAL COLLEGE OF ENGINEERING MANDIDEEP (0127) </h2>

	 

	  <h3> TRAINING RECIPT</h3>

	  
	  

	  <p> RECIPT NUMBER : <?php echo $data['recipt_num']; ?></p>
	  

	  <p> NAME : <?php echo $data['full name']; ?></p>
	  
	  

	  <p>EMAIL : <?php echo $data['email']; ?></p>
	 
	  

	  <p>DEPARTMENT : <?php echo $data['department']; ?></p>
	  
	  

	  <p>ENROLLMENT NUMBER : <?php echo $data['enrollment_num']; ?></p>
	  
	  

	  <p>YEAR :<?php echo $data['year']; ?></p>
	  
	  

	  <p>COURSE : <?php echo $data['course']; ?></p>
	  
	  

	  <p>FEE : <?php echo $data['fee']; ?></p>
	  
	  <br>
	  <br>

	  <h4>signature of HOD</h4>

	  <hr>

	  <h2>BANSAL COLLEGE OF ENGINEERING MANDIDEEP (0127) </h2>

	 

	  <h3> TRAINING RECIPT</h3>

	  
	  

	  <p> RECIPT NUMBER : <?php echo $data['recipt_num']; ?></p>
	  

	  <p> NAME : <?php echo $data['full name']; ?></p>
	  
	  

	  <p>EMAIL : <?php echo $data['email']; ?></p>
	 
	  

	  <p>DEPARTMENT : <?php echo $data['department']; ?></p>
	  
	  

	  <p>ENROLLMENT NUMBER : <?php echo $data['enrollment_num']; ?></p>
	  
	  

	  <p>YEAR :<?php echo $data['year']; ?></p>
	  
	  

	  <p>COURSE : <?php echo $data['course']; ?></p>
	  
	  

	  <p>FEE : <?php echo $data['fee']; ?></p>
	 
	  <br>

	  <h4>signature of HOD</4>
	  
	  <a href="#" class="btn btn-default btn" onclick="myFunction()">
      <span class="glyphicon glyphicon-print"></span> Print 
    </a>

<script type="text/javascript">
	function myFunction() {
  window.print();
}
</script>
    
	  

</body>
</html>