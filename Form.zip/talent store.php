<?php include("header.php")?>
 <style>

a.list-group-item {
    height:auto;
    min-height:220px;
}
a.list-group-item.active small {
    color:#fff;
}

</style>
<div class="container-fluid" style="" >
 
	<br>
	<br>
<div class="container">
    <div class="row">
		<div class="">
        <h1 class="text-center text-primary">Talent and Research</h1>
			<br>
        <div class="list-group">
         
          <a href="talent_stu.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="students/project/808a4e5b-iot.webp" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
					<h4 class="list-group-item-heading">Ashutosh Kumar<br><small>(Electrical Branch)</small></h4>
                    <h3 class="list-group-item-heading">Quadcopter Drone Extracurricular Project </h3>
                    <p class="list-group-item-text">I was the Electrical lead of our team. I personally conceptualized the drone with the unconventional use of cables in tension. The idea: by utilizing cables,
</p>
					
					
					
					
                </div>
                <div class="col-md-3 text-center">
                   
					<br>
					<br>
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Talent</button>
                   
                </div>
          </a>
			
			<a href="talent_stu.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="students/project/018-s99x66.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
					<h4 class="list-group-item-heading">Ashutosh Kumar<br><small>(Electrical Branch)</small></h4>
                    <h3 class="list-group-item-heading">Quadcopter Drone Extracurricular Project </h3>
                    <p class="list-group-item-text">I was the Electrical lead of our team. I personally conceptualized the drone with the unconventional use of cables in tension. The idea: by utilizing cables,
</p>
					
					
					
					
                </div>
                <div class="col-md-3 text-center">
                   
					<br>
					<br>
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Talent</button>
                   
                </div>
          </a>
			
			<a href="talent_stu.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/1527683.png" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
					<h4 class="list-group-item-heading">Ashutosh Kumar<br><small>(Electrical Branch)</small></h4>
                    <h3 class="list-group-item-heading">Quadcopter Drone Extracurricular Project </h3>
                    <p class="list-group-item-text">I was the Electrical lead of our team. I personally conceptualized the drone with the unconventional use of cables in tension. The idea: by utilizing cables,
</p>
					
					
					
					
                </div>
                <div class="col-md-3 text-center">
                   
					<br>
					<br>
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Talent</button>
                   
                </div>
          </a>
			
			
			
        </div>
        </div>
	</div>
</div>

  </div>
  
  
<?php include("footer.php")?>
