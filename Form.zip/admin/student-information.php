	<div class="outter-wp">
									<!--sub-heard-part-->
									  <div class="sub-heard-part">
									   <ol class="breadcrumb m-b-0">
											<li><a href="index.html">Home</a></li>
											<li class="active">student-information</li>
										</ol>
									   </div>
								  <!--//sub-heard-part-->
									<div class="graph-visual tables-main">
											<h2 class="inner-tittle">student-information</h2>
												
											<form method="post">
												<select name="class_students_data" id="selector1" class="form-control1">
							<option>Select Department</option>
													
												
							<option value="">CS</option>
							<option value="">EX</option>
							<option value="">CE</option>
							<option value="">ME</option>
							<option value="">EC</option>
							
													
											
							</select>
								<select name="class_students_data" id="selector1" class="form-control1">
							<option>Select Semester</option>
													
												
							<option value="">1</option>
							<option value="">2</option>
							<option value="">3</option>
							<option value="">4</option>
							<option value="">5</option>
							<option value="">6</option>
							<option value="">7</option>
							<option value="">8</option>
													
											
							</select>
								<input type="submit" name="students_info" class="btn red" value="View Class Data">
									</form>	
										
										
										
															  <div class="graph">
															<div class="tables">
														
																<table class="table table-bordered "> 
															 
																	<thead>
																		<tr>
																			<th>#</th>
																			<th>Photo</th> 
																			<th>F.Name</th> 
																			<th>Address</th>
																			<th>U.Name</th>
																			<th>Pass</th>
																			<th>Father</th>
																			<th>Mother</th>
																			<th>DOB</th>
																			<th>Grade</th>
																			<th>Contact</th>
																			<th>ACTION</th>
																		</tr>
																	</thead>
																	<tbody> 
																		
										
												
														
																		
																
														<tr>
																	<td>1</td>
															<td></td>
															<td>RAM</td>
															<td>BHOPAL</td>
															<td>RAM123</td>
															<td>12345</td>
															<td>XXXXXX</td>
															<td>XXXXXX</td>
															<td>XXXXXX</td>
															<td>XXXXXX</td>
															<td>XXXXXX</td>
															<td><a href="" class="btn green">View profile</a></td>
															
																		</tr>
																
																		<td colspan="12">No any Students information found
																			</td>
																		
										
																	</tbody> 
															
																</table> 
															</div>
													</div>
																
											
										</div>
										<!--//graph-visual-->
									</div>