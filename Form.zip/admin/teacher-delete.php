

<div class="outter-wp">
	<!--sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="index.html">Home</a></li>
			<li class="active">
				teacher-delete
			</li>
		</ol>
	</div>
	<!--//sub-heard-part-->
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">
			teacher-delete
		</h2>

	
			<div class="tables">


				<table class="table table-bordered ">

					<thead>
						<tr>
							<th>#</th>
							<th>Photo</th>
							<th>F.Name</th>
							<th>Address</th>
							<th>Email</th>
							<th>U.Name</th>
							<th>Pass</th>
							<th>Father</th>
							<th>Mother</th>
							<th>DOB</th>
							<th>Qualification</th>
							<th>Contact</th>
							<th>Gender</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>

						


						<tr>
							<th scope="row">
								
							</th>
							<th></th>
							
							<td>
								hello
							</td>
							<td>
								hello
							</td><td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								hello
							</td>
							<td>
								
				<a href="home.php?teacher=teacher-del&teacherid" class="btn red">Delete</a>
					</td>
						</tr>
						
					</tbody>

				</table>

			</div>
		</div>


	</div>
	<!--//graph-visual-->

