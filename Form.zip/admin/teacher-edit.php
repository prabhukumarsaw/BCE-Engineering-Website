<div class="outter-wp">
	<!--sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="index.html">Home</a></li>
			<li class="active">
				teacher-edit
			</li>
		</ol>
	</div>
	<!--//sub-heard-part-->
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">
teacher-edit
		</h2>

	
			<div class="tables">


				<table class="table table-bordered ">

					<thead>
						<tr>
							<th>#</th>
							<th>Photo</th>
							<th>F.Name</th>
							<th>Address</th>
							<th>Email</th>
							<th>U.Name</th>
							<th>Pass</th>
							<th>Father</th>
							<th>Mother</th>
							<th>DOB</th>
							<th>Qualification</th>
							<th>Contact</th>
							<th>Gender</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>

						


						<tr>
							<th scope="row">
								teacher-edit
							</th>
							<th></th>
							<td>
								teacher-edit
							</td>
							<td>
								teacher-edit
							</td><td>
								teacher-edit
							</td>
							<td>
								teacher-edit
							</td><td>
								teacher-edit
							</td><td>
								teacher-edit
							</td><td>
								teacher-edit
							</td><td>
								teacher-edit
							</td><td>
								teacher-edit
							</td>
							<td>
								teacher-edit
							</td>
							<td>
								teacher-edit
							</td>
							
							<td>
								
				<a href="home.php?teacher-editnow" class="btn red">Edit</a>
					</td>
						</tr>
						
					</tbody>

				</table>

			</div>
		</div>


	</div>
	<!--//graph-visual-->

