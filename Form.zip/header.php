<!--
	jay shree Ram
-->
<!DOCTYPE html>
<html lang="zxx">
<head>
<title>BANSAL | Bansal college of Engineering</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--// Meta tag Keywords -->
<!-- css files -->
<link rel="stylesheet" href="css/bootstrap.css">
<!-- Bootstrap-Core-CSS -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<!-- Style-CSS -->
<link rel="stylesheet" href="css/font-awesome.css">
<!-- Font-Awesome-Icons-CSS -->

<link rel="stylesheet" href="css/jquery-ui.css" />
<link rel="stylesheet" href="js/script.js" />
<!-- //css files -->
	
<!-- online-fonts -->

	
	
		<script>
function myFunction() {
   var element = document.body;
   element.classList.toggle("dark-mode");
}
</script>
	
	<script>
		setTimeout(function() {
$('#overlay').modal('show');
}, 8000);

    

	</script>
	
</head>
	
	



	
	
</head>
<body>	
	

<div class="bc" id="home">
  <div class="agileits_bce_banner_nav">
	 <ul>
	  <li><b class="text-left">bce.ac.in | +91 124455600</b></li>
	  <li onclick="myFunction()">dark mode</li>
		
		 </ul>
    <div class="clearfix"> </div>
  </div>
</div>
	
	


<header>
  <div class="logo-with-bg"><a href="index.php"><span>Bce Mandideep</span></a></div>
</header>
	
	

  
    
    <!-- Second navbar for search -->
 
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
		
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
		  
      </button>
		
      <a class="navbar-brand" href="index.php">Home</a>
		 
    </div>
	  

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
         
         <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Academics <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="Directorprof.php"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Director Profile</a></li>
            <li><a href="#"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> Scheme/Syllabus</a></li>
            
            <li><a href="directory.php">Facalty Directory</a></li>
            <li><a href="result.php">Result</a></li>
            <li><a href="ImportantBook.php">Imp. Book</a></li>
            <li><a href="TimeTable.php">Time Table</a></li>
            <li><a href="#">Calender</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Department <span class="caret"></span></a>
          <ul class="dropdown-menu">
			  <li><a href="1styear.php">FIRST YEAR</a></li>
            <li><a href="civil_detail.php">CIVIL ENGINEERING</a></li>
            <li><a href="cs_detail.php">COMPUTER SCIENCE</a></li>
            <li><a href="el_detail.php">ELECTRICAL ENGINEERING</a></li>
            <li><a href="ec_detail.php">ELECTRONIC ENGINEERING</a></li>
            <li><a href="me_detail.php">MECHANICAL ENGINEERING</a></li>
            
            
          </ul>
        </li>
   
      <li><a href="http://161.202.197.85:7061/SMIS/Default.aspx">Online Payment</a></li>
    
     
      <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Facilities <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">SPORT</a></li>
            <li><a href="#">LIBRARY</a></li>
            <li><a href="#">LABS</a></li>
            <li><a href="#">CANTEEN</a></li>
            <li><a href="#">BUSES</a></li>
            <li><a href="#">SMART CLASS</a></li>
            <li><a href="#">OPEN WIFI CAMPUS</a></li>
          </ul>
      </li>
      </ul>
      <ul class="nav navbar-nav navbar">
        <li><a href="talent store.php">Talent Store</a></li>
		  <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Placement & Tranning<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href=""> CAMPUS DRIVE</a></li>
            <li><a href=""> PLACED STUDENTS</a></li>
            <li><a href=""> PLACEMENT RULE & REGULATION</a></li>
             <li><a href=""> NCC</a></li>
            <li><a href=""> NSS</a></li>
         </ul>
        </li>
		   <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Campus Life<span class="caret"></span></a>
          <ul class="dropdown-menu">
			  <li><a href=""> STUDENTS LIFE</a></li>
            <li><a href=""> ART & CULTURE</a></li>
			  
           
           
            
         </ul>
        </li>
		   <li class="dropdown">
          <a  href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp; Login<span class="caret"></span></a>
          <ul class="dropdown-menu">
			  <li><a href="" data-toggle="modal" data-target="#myModal2"> Student Login</a></li>
            <li><a href=""> Staff Login</a></li>
			  
            <li><a href="https://www.rgpv.ac.in/Login/StudentLogin.aspx"> RGPV Login</a></li>
            
           
            
         </ul>
        </li>
		  
		  
		  <li><a data-toggle="modal" data-target="#myModal3" href="#">Register </a></li>
		  <li><label for="search-toggle">
  <div class="search-icon">⌕</div>
</label>

<input class="search" id="search-toggle" type="checkbox">
<div>
  <input class="searchinput" placeholder="search"></input>
</div>
</li>
         
      </ul>
		
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>


	<!-- /.navbar -->
    
   


	<div class="container-fluid" style="background: rgba(0,0,0,0.83); color: beige; padding: 7px 4px; font-family: 'Chewy', cursive; font-size:18px ">
	<marquee>
    <a>Extension of lockdown till 3rd May 2020  | Official Announcement on the Opening of the Institute  | COMMENCEMENT OF ONLINE CLASSES (Registration for CISCO Webex only for faculty members)  | INSTITUTE ALONG WITH ALL OFF CAMPUSES SHALL REMAIN LOCKED DOWN - EXTENDED TILL 14 APRIL 2020 WITH SAME PROVISIONS AS NOTIFIED EARLIER FOR ANY REVIEW/AMENDMENT PLEASE KEEP CHECKING THE INSTITUTE WEBSITE  | Institute along with all Off Campuses shall remain locked down  |  Preponed Summer Vacation Due to COVID-19   | Suspension of Classes due to Covid-19 as a preventive measures  <a href="#">Get Your Tickets &rarr;</a></a>
 </marquee>
		</div>
	

	

	
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
	<div class="modal-dialog">
	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				
				<div class="signin-form profile">
					<h3 class="agileinfo_sign">Student Login</h3>	
					<div class="login-form">
						<form  method="post">
							<input type="email" placeholder="Enter Email Id" required="">
							<input type="password" name="" placeholder="Password" >
							<div class="tp">
								<input type="submit" value="Sign In" name="student_signin">
							</div>
						</form>
					</div>
					<!--<div class="login-social-grids">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-rss"></i></a></li>
						</ul>
					</div>-->
					<p><a href="#" data-toggle="modal" data-target="#myModal3" > Register Here</a></p>
			
				</div>
				
			</div>
		</div>
	</div>
</div>


<!-- Modal2 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
  <div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
				<div class="signin-form profile">
					<h3 class="agileinfo_sign">Student Registration</h3>	
					<div class="login-form">
						<form method="post" >
						   <input type="text" name="username" placeholder="Fullname" required="">
						   <input type="text" name="Fathername" placeholder="Father name" required="">
							<select class="form-control" name="department" placeholder="" required="">
								<option class="">Choose Department</option>
								<option class="select_grade">CE</option>
								<option class="select_grade">CS</option>
								<option class="select_grade">ME</option>
								<option class="select_grade">EC</option>
								<option class="select_grade">EL</option>
						
							</select>
							<input type="text" name="EnrollmentNumber" placeholder="Enrollment Number" required="">
							<label >Year of addmission:</label>
							<input type="date"  required="">
							&nbsp;
							<label for="birthday">Birthday:</label>
  <input type="date" id="birthday" name="birthday">
							 <input type="text" name="address" placeholder="Address" required="">
							<input type="email" name="email" placeholder="Email" required="">
							<input type="text"  placeholder="Personal Phone Number." required="">
							<input type="text"  placeholder="Guardian phone Number" required="">
							<input type="file" placeholder="upload Image" required="">
							<input type="password" name="password" placeholder="Password" required="">
							<input type="password" name="Confirmpassword" placeholder="Confirm Password" required="">
							
							<input type="submit" value="Sign Up" name="student_signup">
						</form>
					</div>
					<p><a href="#"> </a></p>
				</div>
				
      </div>
    </div>
  </div>
</div>
<div class="clearfix"> </div>
<!-- //Modal2 --> 
	
	<div class="modal fade" id="myModal4" tabindex="-1" role="dialog">
  <div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
				<div class="signin-form profile">
					<h3 class="agileinfo_sign">Admission Enquiry</h3><hr/>	
					<div class="login-form">
						<form action="#" method="post" class="mod2">
          <div class="col-md-6 col-xs-6 deva-left-mk">
            <ul>
              <li class="text">Enter Name : </li>
              <li class="agileits-main"><i class="fa fa-user-o" aria-hidden="true"></i>
                <input name="name" type="text" required="">
              </li>
              <li class="text">Date of Birth : </li>
              <li class="agileits-main"><i class="fa fa-calendar" aria-hidden="true"></i>
                <input class="date" id="datepicker" name="Text" type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="" />
              </li>
              <li class="text">Email Address : </li>
              <li class="agileits-main"><i class="fa fa-envelope" aria-hidden="true"></i>
                <input  type="text" required="">
              </li>
				 <li class="text">Select Course : </li>
               
				   <select  class="form-control agileits-main" required="">
                 <option class="select" >hello</option>
                 <option class="select" >hello</option>
              </select>
				  
           		
            </ul>
          </div>
          <div class="col-md-6 col-xs-6 deva-right-mk">
            <ul>
              <li class="text">mobile no  : </li>
              <li class="agileits-main"><i class="fa fa-phone" aria-hidden="true"></i>
                <input name="mobile" type="text" required="">
              </li>
              <li class="text">Address  : </li>
              <li class="agileits-main"><i class="fa fa-home" aria-hidden="true"></i>
                <input name="address" type="text" required="">
              </li>
              <li class="text">District  : </li>
              <li class="agileits-main"><i class="fa fa-map-marker" aria-hidden="true"></i>
                <input name="address" type="text" required="">
              </li>
              <li class="text">State  : </li>
              <li class="agileits-main"><i class="fa fa-map-marker" aria-hidden="true"></i>
                <input name="address" type="text" required="">
              </li>
            </ul>
          </div>
							<b><input type="checkbox"><a href="#"> I agree to receive information regarding my submitted enquiry</a></b>
          <div class="clearfix"></div>
          <div class="agile-submit">
            <input type="submit" value="submit">
          </div>
							
        </form>
								</div>
					
				</div>
				
      </div>
    </div>
  </div>
</div>
	
	