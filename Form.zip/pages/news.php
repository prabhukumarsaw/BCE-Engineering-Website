<div class="container">
  <div class="row">
    <div class=" col-sm-4">
<div class="notice">
  <div class="panel">
    <div class="panel-header">
      <h3>IMPORTANT LINKS</h3>
    </div>
    <div class="panel-body">
      <ul class="latest-news">

	   	<li><a href="@">75th Anniversary for the Anthousa Chapter</a><span>May 11, 2013</span></li>
	
      <li><a href="@">A Sincere Thank You to the Philoptochos Chapters</a><span>July 31, 2012</span></li>

	   		<li><a href="@">2012 National Grants distributed in the Metropolis Philoptochos of San Francisco</a><span>July 30, 2012</span></li>

	   		<li><a href="@">2012 Post Convention Letter from Aphrodite Skeadas</a><span>July 30, 2012</span></li>

	   		<li><a href="@">Kids’n’Cancer: What is a day worth?</a><span>June 22, 2012</span></li>

        <li><a href="@">Kids’n’Cancer: What is a day worth?</a><span>June 22, 2012</span></li>
		</ul>
    </div>
    <div class="panel-footer">
      <a href="#" class="button">Read More</a>
    </div>
  </div>
</div>
       </div>
    <div class="col-sm-4">
      <div class="notice">
  <div class="panel">
    <div class="panel-header">
      <h3>LATEST NEWS</h3>
    </div>
    <div class="panel-body">
      <ul class="latest-news">

	   	<li><a href="@">Infosys Certification Exam</a><span>December 11, 2019</span></li>
	
      <li><a href="@">A Sincere Thank You to the Philoptochos Chapters</a><span>July 31, 2012</span></li>

	   		<li><a href="@">2012 National Grants distributed in the Metropolis Philoptochos of San Francisco</a><span>July 30, 2012</span></li>

	   		<li><a href="@">2012 Post Convention Letter from Aphrodite Skeadas</a><span>July 30, 2012</span></li>

	   		<li><a href="@">Kids’n’Cancer: What is a day worth?</a><span>June 22, 2012</span></li>

        <li><a href="@">Kids’n’Cancer: What is a day worth?</a><span>June 22, 2012</span></li>
		</ul>
    </div>
    <div class="panel-footer">
      <a href="#" class="button">Read More</a>
    </div>
  </div>
</div>
      </div>
    <div class=" col-sm-4">
       <div class="notice">
  <div class="panel">
    <div class="panel-header">
      <h3>EVENTS</h3>
    </div>
    <div class="panel-body">
      <ul class="latest-news">
		  	<li><a href="@">Infosys Certification Exam</a><span>December 11, 2019</span></li>
	
      <li><a href="@">A Sincere Thank You to the Philoptochos Chapters</a><span>July 31, 2012</span></li>

	   		<li><a href="@">2012 National Grants distributed in the Metropolis Philoptochos of San Francisco</a><span>July 30, 2012</span></li>

	   		<li><a href="@">2012 Post Convention Letter from Aphrodite Skeadas</a><span>July 30, 2012</span></li>

	   		<li><a href="@">Kids’n’Cancer: What is a day worth?</a><span>June 22, 2012</span></li>

        <li><a href="@">Kids’n’Cancer: What is a day worth?</a><span>June 22, 2012</span></li>
        
	   		
		</ul>
    </div>
    <div class="panel-footer">
      <a href="#" class="button">Read More</a>
    </div>
  </div>


</div>
      </div>
    </div>
  </div>