<section class="portfolio-sg" id="gallery">
  <h3 class="deva-title">Photo Gallery</h3>
  <br>

  <div class="col-md-3 col-xs-3 gallery-grid gallery1"> <a href="images/g11.jpg" class="swipebox"><img src="images/g11.jpg" class="img-responsive" alt="/">
    <div class="textbox">
      <h4>sawraj</h4>
      <p><i class="fa fa-picture-o" aria-hidden="true"></i></p>
    </div>
    </a> </div>
  <div class="col-md-3 col-xs-3 gallery-grid gallery1"> <a href="images/g11.jpg" class="swipebox"><img src="images/g11.jpg" class="img-responsive" alt="/">
    <div class="textbox">
      <h4>sawraj</h4>
      <p><i class="fa fa-picture-o" aria-hidden="true"></i></p>
    </div>
    </a> </div>
  <div class="col-md-3 col-xs-3 gallery-grid gallery1"> <a href="images/g11.jpg" class="swipebox"><img src="images/g11.jpg" class="img-responsive" alt="/">
    <div class="textbox">
      <h4>sawraj</h4>
      <p><i class="fa fa-picture-o" aria-hidden="true"></i></p>
    </div>
    </a> </div>
  <div class="clearfix"> </div>
</section>