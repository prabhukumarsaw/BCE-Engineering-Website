<?php include("header.php")?>
 <style>

a.list-group-item {
    height:auto;
    min-height:220px;
}
a.list-group-item.active small {
    color:#fff;
}

</style>
<div class="container-fluid" style="" >
  <div class="row">
	  <br>
    
    <img class="center-block img-responsive img-rounded" src="images/bansal-banner-01.jpg">
</div>
	<br>
	<br>
<div class="container">
    <div class="row">
		<div class="well">
        <h1 class="text-center text-primary">Faculty/Staff Directory</h1>
			<br>
        <div class="list-group">
         
          <a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button href="prof_detail.php" type="button"  class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
			
			<a href="prof_detail.php"  class="list-group-item">
                <div class="media col-md-3">
                    <figure class="pull-left">
                        <img class="media-object img-rounded img-responsive" src="images/jainsir.jpg" alt="teachername">
                    </figure>
                </div>
                <div class="col-md-6">
                    <h3 class="list-group-item-heading"> Anirudh vyas </h3>
                    <p class="list-group-item-text">Tag Line......</p>
					<h4 class="list-group-item-heading">Assistant Professor    /   computer science Engineering</h4>
					<h4 class="list-group-item-heading"></h4>
					
                </div>
                <div class="col-md-3 text-center">
                   
                    <button type="button" class="btn btn-primary btn-lg btn-block">View Profile</button>
                   
                </div>
          </a>
        </div>
        </div>
	</div>
</div>

  </div>
  
  
<?php include("footer.php")?>
