<?php include("header.php")?>
 <style>




</style>
<div class="container-fluid" style="background-color: transparent;">
  <div class="row">
	  <br>
   
</div>
<div class="row">
    <div class="col-md-4">
      <div class="">
       <img class="center-block img-responsi img-rounded" src="students/project/ashutosh/ashu.png" width="100%" height="100%"  alt="ashutosh">
		  <section  style="text-align: center; padding:inherit;">
		  	<h3><strong>Ashutosh Kumar</strong></h3>
			  <h5>electrical Branch</h5>
			  <p style="font-family: 'Chewy', cursive; font-size:18px">Bansal College of Engineering<br>Mandideep(M.P) </p>
		  </section>
		  
   
      </div>
  </div>
      <div class="col-md-7">
      <div class="">
        <h3><strong>Quadcopter Drone Extracurricular Project</strong></h3>
		  <br>
  <p>I was the Electrical lead of our team. I personally conceptualized the drone with the unconventional use of cables in tension. The idea: by utilizing cables,</p>          

        </div>
  </div>
  </div>
  </div>
<div class="container">
<section class="portfolio-sg" id="gallery">
  <h3 class="deva-title">Photo Gallery</h3>
  <br>
  <div class="col-md-3 gallery-grid gallery1"  style="margin: 15px;"> <img src="students/project/ashutosh/858112896_190859.jpg" class="img-responsive" alt="/">
   
    </div>

  <div class="col-md-3  gallery-grid gallery1" style="margin: 15px;"> <img src="students/project/ashutosh/858107515_191369.jpg" class="img-responsive" alt="/">
    
    </div>
  <div class="col-md-3  gallery-grid gallery1" style="margin: 15px;"> <img src="students/project/ashutosh/857421607_228824.jpg" class="img-responsive" alt="/">
    
   </div>
	
  
  <div class="clearfix"> </div>
</section>
  
  </div>
<?php include("footer.php")?>
